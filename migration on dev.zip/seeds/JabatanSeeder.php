<?php

use Illuminate\Database\Seeder;
use Carbon\Carbon;

class JabatanSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('jabatan')->insert([
            ['jabatan' => 'Ketua Himpunan', 'periode_id' => 1, 'created_by' => 'Bagus Budhi Riyanto', 'created_at' => Carbon::now()],
            ['jabatan' => 'Wakil Ketua Himpunan', 'periode_id' => 1, 'created_by' => 'Bagus Budhi Riyanto', 'created_at' => Carbon::now()],
            ['jabatan' => 'Sekretaris Himpunan', 'periode_id' => 1, 'created_by' => 'Bagus Budhi Riyanto', 'created_at' => Carbon::now()],
            ['jabatan' => 'Bendahara Himpunan', 'periode_id' => 1, 'created_by' => 'Bagus Budhi Riyanto', 'created_at' => Carbon::now()],
        ]);
    }
}
