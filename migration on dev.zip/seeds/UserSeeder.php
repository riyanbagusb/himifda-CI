<?php

use Illuminate\Database\Seeder;
use Carbon\Carbon;

class UserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('user')->insert([
            ['nim' => '2016230148', 'password' => Hash::make('rahasia'), 'active' => 1, 'role_id' => 1, 'last_login' => Carbon::now()],
        ]);
    }
}
