<?php

use Illuminate\Database\Seeder;
use Carbon\Carbon;

class RoleSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('role')->insert([
            ['role' => 'Super Admin', 'created_by' => 'Bagus Budhi Riyanto', 'created_at' => Carbon::now()],
            ['role' => 'Admin Manager', 'created_by' => 'Bagus Budhi Riyanto', 'created_at' => Carbon::now()],
            ['role' => 'Admin', 'created_by' => 'Bagus Budhi Riyanto', 'created_at' => Carbon::now()],
            ['role' => 'User', 'created_by' => 'Bagus Budhi Riyanto', 'created_at' => Carbon::now()],
        ]);
    }
}
