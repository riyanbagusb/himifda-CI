<?php

use Illuminate\Database\Seeder;
use Carbon\Carbon;

class AnggotaSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('anggota')->insert([
            ['nim' => '2016230148', 'nama' => 'Bagus Budhi Riyanto', 'created_by' => 'Bagus Budhi Riyanto', 'created_at' => Carbon::now()],
        ]);
    }
}
