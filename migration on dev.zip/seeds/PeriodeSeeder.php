<?php

use Illuminate\Database\Seeder;
use Carbon\Carbon;

class PeriodeSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('periode')->insert([
            ['periode' => '2018/2019', 'active' => 1, 'created_by' => 'Bagus Budhi Riyanto', 'created_at' => Carbon::now()],
        ]);
    }
}
