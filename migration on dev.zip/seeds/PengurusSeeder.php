<?php

use Illuminate\Database\Seeder;
use Carbon\Carbon;

class PengurusSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('pengurus')->insert([
            ['nim' => '2016230148', 'jabatan_id' => 1, 'created_by' => 'Bagus Budhi Riyanto', 'created_at' => Carbon::now()],
        ]);
    }
}
