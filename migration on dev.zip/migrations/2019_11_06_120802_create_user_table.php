<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateUserTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::dropIfExists('user');
        Schema::create('user', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('nim', 10);
            $table->string('password', 101);
            $table->boolean('active')->default(0);
            $table->bigInteger('role_id')->unsigned();
            $table->timestamp('last_login')->nullable();
            $table->timestamps();

            $table->foreign('nim')->references('nim')->on('anggota')->onDelete('cascade');
            $table->foreign('role_id')->references('id')->on('role')->onDelete('cascade');
            $table->unique('nim');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('user');
    }
}
